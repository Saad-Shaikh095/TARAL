# OceanEmbed TS-Cast-style Native36 experiment

## Files

- `OceanEmbed_TSCast_NATIVE36_9x9_31day_11H.py`: standalone training script.
- `OceanEmbed_TSCast_NATIVE36_9x9_31day_11H.ipynb`: Kaggle-ready notebook with the full script embedded in its main code cell.

## Run order

1. Attach the OceanEmbed model-data dataset so `/kaggle/input/datasets/lalithiray/oceanembed-modeldata-v1` exists.
2. Enable a CUDA GPU in Kaggle. This script intentionally stops if CUDA is unavailable; CPU execution is not practical for this experiment.
3. Run the notebook while `RUN_MODE = "SMOKE_TEST"`. It reads a real training date, runs a full-grid forward/backward/optimizer step, then evaluates one validation date through the existing SIH metric path. On success it writes `smoke_test_report.json`, including peak GPU memory.
4. Only if smoke testing passes, change the top-level setting to `RUN_MODE = "FULL"` and rerun the code cell. Full mode uses a separate output folder and never seeds its weights from the smoke-test step.

## Architecture and data contract

- TS-Cast-derived adaptation, not a verbatim reproduction of the paper.
- Input: trailing 31-day window ending on the prediction date (no future predictors); 24 dynamic channels plus validity masks, six static channels plus masks, Earth-centred XYZ coordinates, annual sine/cosine time features, and a 31-day × 12-month DUACS ADT-minus-monthly-climatology context.
- Spatial context: shared fully convolutional encoder whose four 3×3 spatial convolution layers yield a 9×9 receptive field. Replicate padding creates boundary context without materializing overlapping patch tensors.
- Temporal encoding: odd-length sequences are replicate-padded before pairwise temporal pooling, ensuring the latest day is not dropped. The four stages produce 31 → 16 → 8 → 4 → 2 bins, then average the final two bins.
- Profile prior/decoder: train-only monthly GLORYS temperature climatology, conditioned through a FiLM depth U-Net; predicts normalized anomalies for all 36 native levels.
- Uncertainty: one log-variance estimate per native depth, trained with masked heteroscedastic Gaussian NLL. Coverage is reported as a diagnostic, not guaranteed calibration.
- Adaptations: DUACS ADT anomalies relative to a train-only monthly climatology substitute for the paper's dynamic-height context; its density-consistency loss is omitted because current labels contain temperature only.

## Training, evaluation, and safety

- Train: 2012–2020; validation: 2021–2022; test: 2023–2024. Input windows stay inside each split. The test period is not evaluated or used for training/model selection.
- Loss: masked Native36 normalized temperature-anomaly Gaussian NLL. Checkpoint selection: existing OceanEmbed SIH 15-depth validation RMSE using the established physical-temperature interpolation and masks.
- Per epoch: 512 randomly sampled, sorted training target dates; each target date supervises all valid grid locations and all 36 native depths. This is a compute-budget choice, not a claim that every training date is used each epoch.
- GPU memory: one full-field sample per GPU; two dates per step only when two CUDA GPUs are visible. AMP is explicitly enabled within the model forward to cover DataParallel worker threads.
- Session budget: 11-hour soft limit with a 15-minute reserve. `latest_model.pt` saves atomically every 64 target dates, at epoch boundaries, and at safe stop; `best_model.pt` updates only when validation SIH RMSE improves. Failure details and peak GPU memory are written to `failure_report.json` when an exception occurs after `main()` starts.
- Preprocessing caches: train-only target climatology/anomaly scales and monthly ADT context are atomically cached under `/kaggle/working/OceanEmbed_Runs/` for reuse between smoke and full runs.
- Preserve/download the FULL output folder before a Kaggle session ends if continuing in a fresh session. When `latest_model.pt` is restored into the same FULL output directory, the script resumes automatically. A custom checkpoint can be provided through `RESUME_CHECKPOINT`, but it must be a TS-Cast checkpoint from this exact architecture version.

## Validation status

The generated script is syntax-checked. The model has passed a synthetic forward/backward test with a 31-day input and 36-depth output. A real-data smoke test on Kaggle and a full GPU training run have **not** been executed in this authoring environment. The Kaggle smoke test is mandatory before FULL mode; it verifies actual dataset compatibility and the GPU memory footprint before committing to training.

Published TS-Cast scores are not an expected score for this adaptation. Inputs, labels, target depth setup, temporal direction, patch size, domain, and evaluation protocol differ.
